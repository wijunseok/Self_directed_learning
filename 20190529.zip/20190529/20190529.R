install.packages("ggplot2")
install.packages("dplyr")
install.packages("readxl")
library(ggplot2)
library(dplyr)
library(readxl)



# 5장 ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ

exam <- read.csv("csv_exam.csv")

summary(exam) # 요약 통계량

install.packages("ggplot2")

# ggplo2의 mpg 데이터를 데이터 프레임 형태로 불러오기
# 더블 콜론(::)을 이용하면 특정 패키지에 들어 있는 함수나 데이터를 지정할 수 있습니다.
mpg <- as.data.frame(ggplot2::mpg)
# as.data.frame()은 데이터 속성을 데이터 프레임 형태로 바꾸는 함수입니다.

head(mpg)
View(mpg)
?mpg
summary(mpg)





#변수명 변경하기
df_raw <- data.frame(var1 = c(1,2,1) , var2 
                     = c(1,2,3))
df_raw





# dplyr 설치
install.packages("dplyr")
# dplyr 로드
library(dplyr)




df_new <- df_raw
# var2를 v2로 수정
df_new <- rename(df_new , v2 = var2)
df_new

df_mpg <- rename(mpg , city = cty , highway = hwy)
df_mpg











# 변수 조합해 파생변수 만들기 
df <- data.frame(var1 = c(3,4,5) , var2 = c(6,6,7))
df

df$var_sum <- df$var1 + df$var2
df

df$var_mean <- (df$var1 + df$var2)/2
df

df_mpg$total <- (df_mpg$city + df_mpg$highway)/2
df_mpg
mean(df_mpg$total)








# 조건문을 활용해 파생변수 만들기
summary(df_mpg$total)

hist(df_mpg$total)
#히스토그램은 값의 빈도를 막대 길이로 표현한 그래프입니다. 히스토그램을 보면 어떤 값을 지닌 데이터가 많은지 전반적인 분포를 알 수 있습니다.

df_mpg$test <-ifelse(df_mpg$total >= 20 ,
                     "pass","fail")
head(df_mpg , 20)
# 연비 합격 빈도표 생성 table
table(df_mpg$test)


library(ggplot2)
qplot(df_mpg$test)

df_mpg$grade <- ifelse(df_mpg$total >= 30 ,"A" , ifelse(df_mpg$total >= 20 , "B" , "C"))

head(df_mpg,20)

table(df_mpg$grade)
qplot(df_mpg$grade)


library(dplyr)


do <- as.data.frame(ggplot2::midwest)
head(do,10)

do <- rename(do , total = poptotal , asian =
               popasian)
head(do,10)

do$total_mean <- do$asian/do$total
tail(do,10)
hist(do$total_mean)

summary(do) # Mean   :0.004872

do$mean <- ifelse(do$total_mean >= 0.004872 , "large" , "small")
tail(do ,10)
table(do$mean)
qplot(do$mean)





# 6장 시작 ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ



#dplyr 함수 기능
#filter() 행 추출
#select() 열(변수) 추출
#arrange() 정렬
#mutate() 변수 추가
#summarise() 통계치 산출
#group_by() 집단별로 나누기
#left_join() 데이터 합치기(열)
#bind_rows() 데이터 합치기(행)

library(dplyr)
# exam 에서 class 가 1인 경우만 추출해 출력 
exam %>% filter(class==1)
exam %>% filter(class==2)
exam %>% filter(class!=1)
exam %>% filter(class!=3)
exam %>% filter(math > 50 & english >=90 & class == 2 | class == 1)
exam %>% filter(class %in% c(1,2,3))

class1 <- exam %>% filter(class==1)
mean(class1$english)


# 혼자서 문제 풀기
summary(mpg)
mpg

# Q1
displ4 <- mpg %>% filter(displ <= 4)
summary(displ4$displ)
mean(displ4$hwy)
displ5 <- mpg %>% filter(displ >= 5)
summary(displ5$displ)
mean(displ5$hwy)

# Q2
audi <- mpg %>% filter(manufacturer == "audi")
mean(audi$cty)

# Q3
hwy <- mpg %>% filter(manufacturer %in% c("chevrolet", "ford", "honda"))

mean(hwy$hwy)

#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ

exam %>% select (math)
exam %>% select (-math , -english)

exam %>% filter(class == 1 ) %>% select(english)

exam %>% select(id , math) %>% head(10)

m <- mpg %>% select(class , cty)
df_suv <- m %>% filter(class == "suv")
mean(df_suv$cty)

# math 오름차순 정렬
exam %>% arrange(math)
exam %>% arrange(class , math)
# math 내림차순 정렬
exam %>% arrange(desc(class,math))

# 혼자서 해보기 아우디 자동차 hwy 1~5위
mpg %>% filter(manufacturer == "audi") %>% arrange(desc(hwy)) %>% head(5)

#파생변수 추가
exam %>% mutate(total = math + english + science , mean = (math + english + science)/3) %>% head

# mutate () 에 ifelse() 적용하기
exam %>% mutate(test = ifelse(science >= 60 ,"pass" , "fail")) %>% head


exam %>%
  mutate(total = math + english + science) %>% # 총합 변수 추가
  arrange(total) %>% # 총합 변수 기준 정렬
  head # 일부 추출

# 혼자서 해보기
mpg_test <- mpg
mpg_test <- mpg_test %>% mutate(total = cty + hwy) %>% tail(5)
mpg_test

mpg_test %>% mutate(avg = total/2) %>% tail(5)


# 집단별로 요약하기

exam %>% summarise(mean_math = mean(math))
exam %>% group_by(class) %>% summarise(mean_math = mean(math))
exam %>% group_by(class) %>% summarise(mean_math = mean(math) , sum_math = sum(math) , median_math = median(math) , n=n())


mpg %>% group_by(manufacturer , drv) %>% summarise(mean_cty = mean(cty)) %>% head(5)

mpg %>% group_by(manufacturer) %>% filter(class == "suv") %>% mutate(tot = (cty+hwy)/2) %>% summarise(mean_not = mean(tot)) %>% arrange(desc(mean_not)) %>% head(5)



# 가로로 합치기

test1 <- data.frame(id = c(1,2,3,4,5) , midterm = c(60,80,70,90,85))

test2 <- data.frame(id = c(1,2,3,4,5) , final = c(70,83,65,95,80))

total <- left_join(test1 , test2 , by = "id")
total

name <- data.frame(class = c(1, 2, 3, 4, 5), teacher = c("kim", "lee", "park", "choi", "jung"))
name

exam_new <- left_join(exam , name , by ="class")
exam_new

# 세로로 합치기

# 학생 1~5번 시험 데이터 생성
group_a <- data.frame(id = c(1, 2, 3, 4, 5), test = c(60, 80, 70, 90, 85))

# 학생 6~10번 시험 데이터 생성
group_b <- data.frame(id = c(6, 7, 8, 9, 10),test = c(70, 83, 65, 95, 80))

group_all <- bind_rows(group_a, group_b)
group_all

fuel <- data.frame(fl = c("c", "d", "e", "p", "r"),price_fl = c(2.35, 2.38, 2.11, 2.76, 2.22),stringsAsFactors = F)

mpg <- left_join(mpg , fuel , by = "fl")
mpg

mpg %>% select(model , fl , price_fl) %>% head(5)

#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ


# 7장 시작 ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ

df <- data.frame(sex = c("M" , "F" , NA , "M" , "F"), score = c(5,4,3,4,NA))
table(is.na(df))

library(dplyr)
df %>% filter(!is.na(score))

df_nomiss <- df %>% filter(!is.na(score)) # score 결측치 제거
mean(df_nomiss$score)

df_nomiss <- df %>% filter(!is.na(score) & !is.na(sex)) # score, sex 결측치 제거
df_nomiss

# 결측지가 하나라도 있으면 제거하기
df_nomiss2 <- na.omit(df) # 모든 변수에 결측치 없는 데이터 추출
df_nomiss2 







# 함수의 결측치 제외 기능 이용하기 na.rm

mean(df$score, na.rm = T) # 결측치 제외하고 평균 산출

exam <- read.csv("csv_exam.csv") # 데이터 불러오기
exam[c(3, 8, 15), "math"] <- NA # 3, 8, 15행의 math에 NA 할당
exam

# math 평균 산출
exam %>% summarise(mean_math = mean(math))
# math 결측치 제외하고 평균 산출
exam %>% summarise(mean_math = mean(math, na.rm = T))

# 평균 산출 # 합계 산출 # 중앙값 산출
exam %>% summarise(mean_math = mean(math, na.rm = T), sum_math = sum(math, na.rm = T), median_math = median(math, na.rm = T)) 

exam$math <- ifelse(is.na(exam$math), 55, exam$math) # math가 NA면 55로 대체
table(is.na(exam$math)) # 결측치 빈도표 생성





# 이상치 제거하기

outlier <- data.frame(sex = c(1,2,1,3,2,1) , score = c(5,4,3,4,2,6))

# 결측 처리하기
# sex가 3이면 NA 할당
outlier$sex <- ifelse(outlier$sex == 3, NA, outlier$sex)
# score가 5보다 크면 NA 할당
outlier$score <- ifelse(outlier$score > 5, NA, outlier$score)

outlier %>% filter(!is.na(sex) & !is.na(score)) %>% group_by(sex) %>% summarise(mean_score = mean(score))

boxplot(mpg$hwy)
boxplot(mpg$hwy)$stats
# 12~37 벗어나면 NA 할당
mpg$hwy <- ifelse(mpg$hwy < 12 | mpg$hwy > 37, NA, mpg$hwy)
table(is.na(mpg$hwy))

mpg %>% group_by(drv) %>% summarise(mean_hwy = mean(hwy, na.rm = T))

#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ












# 8 장 시작 ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ

install.packages("ggplot2")
library(ggplot2)

# x축은 displ, y축은 hwy로 지정해 배경 생성
ggplot(data = mpg, aes(x = displ, y = hwy))
ggplot(data = mpg, aes(x = displ, y = hwy)) + geom_point()
# 데이터 축 ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ # 그래프 종류 ㅡㅡ # 세부 설정 ㅡㅡㅡㅡㅡㅡ
ggplot(data = mpg, aes(x = displ, y = hwy)) + geom_point() + xlim(3,6) + ylim(10 , 30)

#혼자서 해보기 
#Q1
ggplot(data = mpg, aes(x = cty, y = hwy)) + geom_point()
#Q2
ggplot(data = midwest, aes(x = poptotal, y = popasian)) + geom_point() + xlim(0,500000) + ylim(0,10000)


library(dplyr)

df_mpg = mpg %>% group_by(drv) %>% summarise(mean_hwy = mean(hwy)) 
ggplot(data = df_mpg, aes(x = drv, y = mean_hwy)) + geom_col() 
# 크기 순으로 정렬 reorder x 축 과 기준 정하기
ggplot(data = df_mpg, aes(x = reorder(drv, -mean_hwy), y = mean_hwy)) + geom_col()
ggplot(data = mpg, aes(x = hwy)) + geom_bar()

#시계열 그래프
ggplot(data = economics, aes(x = date, y = unemploy)) + geom_line()


# 혼자서 해보기
#Q1
ggplot(data = economics, aes(x = date, y = psavert)) + geom_line()


mpg = as.data.frame(ggplot2::mpg)
class_mpg = mpg %>% filter(class %in% c("compact", "subcompact", "suv"))

ggplot(data=class_mpg , aes(x=class , y=cty)) + geom_boxplot()
