install.packages("ggplot2")
install.packages("dplyr")
install.packages("readxl") # 엑셀 쓰기
install.packages("rJava")
install.packages("memoise")
install.packages("KoNLP")
install.packages("Stringr")
install.packages("devtools")
install.packages("wordcloud") #워드 클라우드
install.packages("ggiraphExtra") # 단계 구분도 
install.packages("maps")
install.packages("mapproj") # 지도에 표현할 범죄 데이터와 배경이 될 지도 데이터가 준비되었으니 ggiraphExtra 패키지의 ggChoropleth()를 이용해 단계 구분도를 만들어 보겠습니다.
library(wordcloud)
library(RColorBrewer)
library(stringr)
library(ggplot2)
library(maps)
library(dplyr)
library(tibble) # 은 dplyr 설치시 자동으로 함께 설치
library(readxl)
library(KoNLP)
library(ggiraphExtra)
library(mapproj)

str(USArrests)
head(USArrests)

crime <- rownames_to_column(USArrests, var = "state") # 행 State
crime$state = tolower(crime$state) # 다 소문자로 만들기

str(crime)
states_map = map_data("state")
str(states_map)

ggChoropleth(data = crime, # 지도에 표현할 데이터
             aes(fill = Murder, # 색깔로 표현할 변수
                 map_id = state), # 지역 기준 변수
             map = states_map) # 지도 데이터

ggChoropleth(data = crime, # 지도에 표현할 데이터
             aes(fill = Murder, # 색깔로 표현할 변수
                 map_id = state), # 지역 기준 변수
             map = states_map, # 지도 데이터
             interactive = T) # 인터랙티브


# 대한민국 시도별 인구 단계 구분도 만들기 ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ

devtools::install_github("cardiomoon/kormaps2014") #install_github()를 이용해 패키지 개발자가 깃허브에 공유한 kormaps2014 패키지를 설치하고 로드하겠습니다.
library(kormaps2014) # 어떤 패키지들은 CRAN에 등록되어 있지 않고 깃허브를 통해 공유됩니다. devtools 패키지의 install_github()를 이용하면 깃허브에 공유된 패키지를 설치할 수 있습니다.

korpop1
str(changeCode(korpop1)) # kormaps2014 패키지의 changeCode()를 이용해 인코딩을 CP949로 변환한 후 str()에 적용하면 한글이 깨지지 않고 출력됩니다.
# 대한민국 시도 지도 데이터 준비하기기

library(dplyr)
korpop1 <- rename(korpop1,
                  pop = 총인구_명,
                  name = 행정구역별_읍면동)

str(changeCode(kormap1))

ggChoropleth(data = korpop1, # 지도에 표현할 데이터
             aes(fill = pop, # 색깔로 표현할 변수
                 map_id = code, # 지역 기준 변수
                 tooltip = name), # 지도 위에 표시할 지역명
             map = kormap1, # 지도 데이터
             interactive = T) # 인터랙티브




str(changeCode(tbc))

ggChoropleth(data = tbc, # 지도에 표현할 데이터
             aes(fill = NewPts, # 색깔로 표현할 변수
                 map_id = code, # 지역 기준 변수
                 tooltip = name), # 지도 위에 표시할 지역명
             map = kormap1, # 지도 데이터
             interactive = T) # 인터랙티브

