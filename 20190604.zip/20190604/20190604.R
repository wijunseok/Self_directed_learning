# 12장
install.packages("plotly")
library(plotly)

# 인터렉티브 그래프란 ?
# 마우스 움직임에 반응하여 실시간으로 형태가 변하는 그래프
# 그래프를 HTML 포맷으로 저장하면 , 일반 사용자들도 웹 브라우저를 이용해 그래플를 조작 할 수 있다.

# 인터랙티브 그래프 만들기

# 산점도의 점을 drv(구동박식)별로 다른 색으로 표현하도록 col = drv 를 지정정
library(ggplot2)
p = ggplot(data=mpg , aes(x=displ,y=hwy ,col = drv)) + geom_point()
ggplotly(p)
# 뷰어 창에서 Export -> Save as WebPage 를 클릭하면 인터렉티브 그래프를 HTML 포맷으로 저장 할 수 있다.

# 인터랙티브 막대 그래프 만들기
# 데이타 = ggplot2 패키지에 내장된 diamonds 사용 , 
p = ggplot(data=diamonds , aes(x=cut , fill = clarity)) + geom_bar(position = "dodge")
ggplotly(p)



# 12장 - 2
# dygraphs 패키지로 인터랙티브 시계열 그래프 만들기
# 시계열 : 시간에 따른 데이터의 변화를 표현한 인터랙티브 시계열 그래프 , 마우스로 시간 축을 움직이면서 시간에 따라 데이터가 어떻게 변하는지 자세히 살펴 볼 수 있다.

install.packages("dygraphs")
library(dygraphs)
head(economics)

# 데이터가 시간 순서 속성을 지니는 xts 데이터 타입으로 되어 있어야 한다. xts()를 이용해 economics 데이터의 umemploy(실업작수)를 xts 타입으로 변경

library(xts)
eco = xts(economics$unemploy , order.by = economics$date)
# %>% 를 이용해 dyRangeSelector()를 추가하면 그래프 아래에 날짜 범위 선택 기능이 추가
dygraph(eco) 
dygraph(eco) %>% dyRangeSelector()

# 여러값 동시에 표현하기

eco_a = xts(economics$psavert , order.by = economics$date)
eco_b = xts(economics$unemploy/1000 , order.by = economics$date)

# cbind()를 이용해 가로로 결합하고 , 변수명도 변경하도록 수정 그런데 데이터 프레임이 아니라 xts 타입이기 때문에 rename() 을 적용이 불가능하므로 colnames()를 이용해 변수명 수정

eco2 = cbind(eco_a , eco_b)
eco2
colnames(eco2) = c("psavert" , "unemploy")
head(eco2)

dygraph(eco2) %>% dyRangeSelector()



