install.packages("ggplot2")
install.packages("dplyr")
install.packages("readxl")
library(ggplot2)
library(dplyr)
library(readxl)

#9 장 시작ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ

#실습에 사용할 복지패널데이터는 통계분석 소프트웨어인 SPSS 전용 파일로 되어 있습니다. #foreign 패키지를 이용하면 SPSS, SAS, STATA 등 다양한 통계분석 소프트웨어의 파일을 불러올 수 있습니다.

install.packages("foreign") # foreign 패키지 설치
library(foreign) # SPSS 파일 불러오기
library(ggplot2) # 시각화
library(dplyr) # 전처리
library(readxl) # 엑셀 파일 불러오기

raw_welfare = read.spss(file = "Koweps_hpc10_2015_beta1.sav",to.data.frame = T)
welfare = raw_welfare
welfare

head(welfare)
tail(welfare)
View(welfare)
dim(welfare)
str(welfare)
summary(welfare)

welfare = rename(welfare ,
                 sex = h10_g3, # 성별
                 birth = h10_g4, # 태어난 연도
                 marriage = h10_g10, # 혼인 상태
                 religion = h10_g11, # 종교
                 income = p1002_8aq1, # 월급
                 code_job = h10_eco9, # 직업 코드
                 code_region = h10_reg7) # 지역 코드

class(welfare$sex)
table(welfare$sex)

welfare$sex = ifelse(welfare$sex == 9, NA , welfare$sex)
table(is.na(welfare$sex))
welfare$sex = ifelse(welfare$sex == 1 , "male" , "female")
table(welfare$sex)
qplot(welfare$sex)

class(welfare$income)
summary(welfare$income)
qplot(welfare$income) + xlim(0,1000)

#이상치 처리
welfare$income = ifelse(welfare$income %in% c(0,9999) , NA , welfare$income)
table(is.na(welfare$income))

sex_income = welfare %>% filter(!is.na(income)) %>% group_by(sex) %>% summarise(mean_income = mean(income))
sex_income

ggplot(data = sex_income , aes(x=sex, y= mean_income)) + geom_col()




welfare$birth = ifelse(welfare$birth == 9999 , NA , welfare$birth)
table(is.na(welfare$birth))

welfare$age = 2015 - welfare$birth + 1
summary(welfare$age)
qplot(welfare$age)

age_income = welfare %>% filter(!is.na(income)) %>% group_by(age) %>% summarise(mean_income = mean(income))
head(age_income)

ggplot(data = age_income , aes(x=age, y=mean_income)) + geom_line()

#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ


welfare <- welfare %>% mutate(ageg = ifelse(age < 30, "young", ifelse(age <= 59, "middle", "old")))
table(welfare$ageg)

ageg_income = welfare %>% filter(!is.na(income)) %>% group_by(ageg) %>% summarise(mean_income = mean(income))
ageg_income

ggplot(data = ageg_income, aes(x = ageg, y = mean_income)) + geom_col()

# 순서 young , middle , old
ggplot(data = ageg_income, aes(x = ageg, y = mean_income)) + geom_col() + scale_x_discrete(limits = c("young", "middle", "old"))

#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ

sex_income = welfare %>% filter(!is.na(income)) %>% group_by(ageg, sex) %>% summarise(mean_income = mean(income))
sex_income

#fill 로 색 채우기
ggplot(data = sex_income, aes(x = ageg, y = mean_income, fill = sex)) + geom_col() + scale_x_discrete(limits = c("young", "middle", "old"))
#fill 로 색 채우고 성별 나누기기
ggplot(data = sex_income, aes(x = ageg, y = mean_income, fill = sex)) + geom_col(position = "dodge") + scale_x_discrete(limits = c("young", "middle", "old"))


sex_age <- welfare %>% filter(!is.na(income)) %>% group_by(age, sex) %>% summarise(mean_income = mean(income))
# 그래프 라인 , sex 나누기
ggplot(data = sex_age, aes(x = age, y = mean_income, col = sex)) + geom_line() 

#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ

class(welfare$code_job)
table(welfare$code_job)

list_job = read_excel("Koweps_Codebook.xlsx", col_names = T, sheet = 2)
head(list_job)

dim(list_job)

welfare = left_join(welfare , list_job , id = "code_job")

welfare %>% filter(!is.na(code_job)) %>% select(code_job , job) %>% head(5)

job_income = welfare %>% filter(!is.na(job) & !is.na(income)) %>% group_by(job) %>% summarise(mean_income = mean(income)) 

head(job_income)

top = job_income %>% arrange(desc(mean_income)) %>% head(10)
top


# coord_flip() 막대를 90 도 회전전
ggplot(data = top , aes(x=reorder(job,mean_income), y= mean_income )) + geom_col() + coord_flip()

#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ

bottom <- job_income %>% arrange(mean_income) %>% head(10)
bottom
ggplot(data = bottom,aes(x=reorder(job,-mean_income), y= mean_income )) + geom_col() + coord_flip() + ylim(0,850)

job_male <- welfare %>% filter(!is.na(job) & sex == "male") %>% group_by(job) %>% summarise(n = n()) %>% arrange(desc(n)) %>% head(10)
job_male

job_female = welfare %>% filter(!is.na(job) & sex != "male") %>% group_by(job) %>% summarise(n=n()) %>% arrange(desc(n)) %>% head(10) 
job_female

ggplot(data = job_male , aes(x=reorder(job , n) , y = n)) + geom_col() + coord_flip()

ggplot(data = job_female , aes(x=reorder(job , n) , y = n)) + geom_col() + coord_flip()


# 원자료를 이용해 막대 그래프를 만들 때는 geom_bar() 를 사용
# 요약표를 이용해 막대 그래프를 만들 때는 geom_col() 을 사용

#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ

welfare$religion <- ifelse(welfare$religion == 1, "yes", "no")
table(welfare$religion)
qplot(welfare$religion)



#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ

welfare$group_marriage <- ifelse(welfare$marriage == 1, "marriage", ifelse(welfare$marriage == 3, "divorce", NA))
table(welfare$group_marriage)
table(is.na(welfare$group_marriage))
qplot(welfare$group_marriage)

#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ

# 종교 유무에 따른 이혼율 표 만들기
religion_marriage = welfare %>% filter(!is.na(welfare$group_marriage)) %>% group_by(religion , group_marriage) %>% summarise(n = n()) %>% mutate(tot_group = sum(n)) %>% mutate(pct = round(n/tot_group*100,1))

religion_marriage





religion_marriage2 <- welfare %>% filter(!is.na(group_marriage)) %>% count(religion, group_marriage) %>% group_by(religion) %>% mutate(pct = round(n/sum(n)*100, 1))
religion_marriage2


# 표 만들기

divorce = religion_marriage %>% filter(group_marriage == "divorce") %>% select(religion , pct)
divorce

ggplot(data = divorce , aes(x=religion, y =pct)) + geom_col()

#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ

# 연령대별 이혼율 표 만들기

ageg_marriage = welfare %>% filter(!is.na(group_marriage)) %>% group_by(ageg , group_marriage) %>% summarise(n=n()) %>% mutate(tot_group = sum(n)) %>% mutate(pct = round(n/tot_group*100,1))
ageg_marriage

ageg_marriage <- welfare %>% filter(!is.na(group_marriage)) %>% count(ageg, group_marriage) %>% group_by(ageg) %>% mutate(pct = round(n/sum(n)*100, 1))
ageg_marriage


# 초년생 제외 , 이혼 한사람 
ageg_divorce <- ageg_marriage %>% filter(ageg != "young" & group_marriage == "divorce") %>% select(ageg, pct)
ageg_divorce

ggplot(data = ageg_divorce , aes(x=ageg, y=pct)) + geom_col() + coord_flip()


# 연령대 , 종교 유무 , 결혼 상태 , 초년생 제외

ageg_religion_marriage <- welfare %>% filter(!is.na(group_marriage) & ageg != "young") %>% count(ageg, religion, group_marriage) %>% group_by(ageg, religion)%>% mutate(pct = round(n/sum(n)*100, 1))
ageg_religion_marriage

# 연령대 및 종교 유무별 이혼율 표 만들기
df_divorce = ageg_religion_marriage %>% filter(group_marriage == "divorce") %>% select(ageg , religion , pct)
df_divorce

ggplot(data = df_divorce , aes(x= ageg , y = pct , fill = religion )) + geom_col(position = "dodge")


#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ

# 지역 코드 목록 만들기
 
list_region = data.frame(code_region = c(1:7) , region = c("서울",
                                                           "수도권(인천/경기)",
                                                           "부산/경남/울산",
                                                           "대구/경북",
                                                           "대전/충남",
                                                           "강원/충북",
                                                           "광주/전남/전북/제주도"))

list_region

welfare = left_join(welfare , list_region , id = "code_region")

welfare %>% select(code_region, region) %>% tail(10)

region_ageg = welfare %>% group_by(region , ageg) %>% summarise(n=n()) %>% mutate(tot_group = sum(n)) %>% mutate(pct = round(n/tot_group*100,2))
head(region_ageg,10)

region_ageg = welfare %>% count(region,ageg) %>% group_by(region) %>% mutate(pct = round(n/sum(n)*100,2))

region_ageg

ggplot(data = region_ageg , aes(x=region, y= pct , fill = ageg)) + geom_col() + coord_flip()







# 노년층 비율 내림차순 정렬
list_order_old <- region_ageg %>% filter(ageg == "old") %>% arrange(pct)
# 지역명 순서 변수 만들기
order <- list_order_old$region

ggplot(data = region_ageg, aes(x = region, y = pct, fill = ageg)) + geom_col() + coord_flip() + scale_x_discrete(limits = order)




#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ


# 연령대 순으로 막대 색깔 나열하기

# factor()를 이용해 ageg 변수를 factor 타입으로 변환하고, level 파라미터를 이용해 순서를 지정합니다
# levels 가 없습니다

region_ageg$ageg = factor(region_ageg$ageg , levels = c("old" , "middle" , "young")) 
levels(region_ageg$ageg)













#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ


#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ



#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ



#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ


#ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ



