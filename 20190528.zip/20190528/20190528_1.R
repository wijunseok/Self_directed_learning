# ggplot2 패키지 설치
install.packages("ggplot2")
library(ggplot2)
# 여러 문자로 구성된 변수 생성
x <- c("a", "a", "b", "c")
x
# 빈도 막대 그래프 출력
qplot(x)

# data에 mpg, x축에 hwy 변수 지정해 그래프 생성
qplot(data = mpg, x = hwy)
# x축 cty
qplot(data = mpg, x = cty)
# x축 drv, y축 hwy
qplot(data = mpg, x = drv, y = hwy)
# x축 drv, y축 hwy, 선 그래프 형태
qplot(data = mpg, x = drv, y = hwy, geom = "line")
# x축 drv, y축 hwy, 상자 그림 형태
qplot(data = mpg, x = drv, y = hwy, geom = "boxplot")
# x축 drv, y축 hwy, 상자 그림 형태, drv별 색 표현
qplot(data = mpg, x = drv, y = hwy, geom = "boxplot", colour = drv)

english <- c(90, 80, 60, 70) # 영어 점수 변수 생성
english
math <- c(50, 60, 100, 20) # 수학 점수 변수 생성
math
df_midterm <- data.frame(english, math)
df_midterm
class <- c(1, 1, 2, 2)
class
df_midterm <- data.frame(english, math, class)
df_midterm

mean(df_midterm$english)
mean(df_midterm$math)

df_midterm <- data.frame(english = c(90, 80, 60, 70),
                         math = c(50, 60, 100, 20),
                         class = c(1, 1, 2, 2))
df_midterm

install.packages("readxl")
library(readxl)
df_exam <- read_excel("excel_exam.xlsx") # 엑셀 파일을 불러와 df_exam에 할당
df_exam
# 파일 경로 지정
df_exam <- read_excel("d:/easy_r/excel_exam.xlsx")
mean(df_exam$english)
mean(df_exam$science)

df_exam_novar <- read_excel("excel_exam_novar.xlsx")
df_exam_novar

df_exam_novar <- read_excel("excel_exam_novar.xlsx", col_names = F)
df_exam_novar

df_exam_sheet <- read_excel("excel_exam_sheet.xlsx", sheet = 3)

df_csv_exam <- read.csv("csv_exam.csv")
df_csv_exam

df_csv_exam <- read.csv("csv_exam.csv", stringsAsFactors = F)

df_midterm <- data.frame(english = c(90, 80, 60, 70),
                         math = c(50, 60, 100, 20),
                         class = c(1, 1, 2, 2))
df_midterm

write.csv(df_midterm , file = "df_midterm.csv")
save(df_midterm, file = "df_midterm.rda")
rm(df_midterm)
rm(x)
df_midterm

load("df_midterm.rda")
df_midterm



# 엑셀 파일 불러와 df_exam에 할당하기
df_exam <- read_excel("excel_exam.xlsx")
# csv 파일 불러와 df_csv_exam에 할당하기
df_csv_exam <- read.csv("csv_exam.csv")
# Rda 파일 불러오기
load("df_midterm.rda")

exam <- read.csv("csv_exam.csv")
exam

head(exam,10)
tail(exam,10)
View(exam)
dim(exam)
str(exam)


