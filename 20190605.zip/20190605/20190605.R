
# 13장

# 13장 - 1
# 통계 분석은 기술 통계와 추론 통계로 나눌 수 있다. 데이터를 요약해 설명하는 통계 기법을 '기술 통계' 라고 한다. ex) 사람들이 받는 월급을 집계해 전체 월급 평균을 구한다면 이는 '기술 통계 분석' 입니다.

# 추론 통계는 단순히 숫자르ㅜㄹ 요약하는 것을 넘어 어떤 값이 발생할 확률을 계산하는 통계 기법 이다. ex) 수집된 데이터에서 성별에 따라 월급에 차이가 있는 것으로 나타나면 , 이런 차이가 우연히 발생할 확률을 계산한다. 

# 통계적 가설 검정
# 유의확률을 이용해 가설을 검정하는 방법을 ‘통계적 가설 검정’이라고 합니다. ‘유의확률’은 실제로는 집단 간 차이가 없는데 우연히 차이가 있는 데이터가 추출될 확률을 의미합니다.


install.packages("ggplot2")
library(ggplot2)
install.packages("dplyr")
library(dplyr)

# 13장 - 2

# 직접 해보기 - compact 자동차와 suv 자동차의 도시 연비 t 검정
mpg = as.data.frame(ggplot2::mpg)
mpg_diff = mpg %>% select(class, cty) %>% filter(class %in% c("compact", "suv"))
head(mpg_diff)

table(mpg_diff$class)

# compact   suv 
#   47       62

# t.test()를 이용해 t 검정을 하겠습니다. t.test() 는 R 에 내장된 함수
t.test(data = mpg_diff , cty ~ class , var.equal = T)

# data:  cty by class
# t = 11.917, df = 107, p-value < 2.2e-16
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#  5.525180 7.730139
# sample estimates:
# mean in group compact     mean in group suv 
# 20.12766              13.50000 

# 'p-value'가 유의확률을 의미합니다. 일반적으로 유의확률 5% 를 판단 기준으로 삼는다.
# p-value 가 0.05 미만이면 '집단 간 차이가 통계적으로 유의하다' 고 해석한다.



# 직접 해보기2 - 일반 휘발유와 고급 휘발유의 도시 연비 t 검정

mpg_diff2 <- mpg %>% select(fl, cty) %>% filter(fl %in% c("r", "p")) # r:regular, p:premium
table(mpg_diff2$fl)
##
## p r
## 52 168
t.test(data = mpg_diff2, cty ~ fl, var.equal = T)
## data: cty by fl
## t = 1.0662, df = 218, p-value = 0.2875
## alternative hypothesis: true difference in means is not equal to 0
## 95 percent confidence interval:
## -0.5322946 1.7868733
## sample estimates:
## mean in group p mean in group r
## 17.36538 16.73810


# 13장 - 3

economics <- as.data.frame(ggplot2::economics)
cor.test(economics$unemploy, economics$pce)
##
## Pearson’s product-moment correlation
##
## data: economics$unemploy and economics$pce
## t = 18.605, df = 572, p-value < 2.2e-16
## alternative hypothesis: true correlation is not equal to 0
## 95 percent confidence interval:
## 0.5603164 0.6625460
## sample estimates:
## cor
## 0.6139997

# 직접 해보기 상관행렬 히트맵 만들기 여러 변수의 관련성을 한 번에 알아보고자 할 경우, 모든 변수의 상관 관계를 나타낸 상관 행렬(Correlation Matrix)을 만듭니다. 상관행렬을 보면 어떤 변수끼리 관련이 크고 적은지 파악할 수 있습니다.

head(mtcars)
## mpg cyl disp hp drat wt qsec vs am gear carb
## Mazda RX4 21.0 6 160 110 3.90 2.620 16.46 0 1 4 4
## Mazda RX4 Wag 21.0 6 160 110 3.90 2.875 17.02 0 1 4 4
## Datsun 710 22.8 4 108 93 3.85 2.320 18.61 1 1 4 1
## Hornet 4 Drive 21.4 6 258 110 3.08 3.215 19.44 1 0 3 1
## Hornet Sportabout 18.7 8 360 175 3.15 3.440 17.02 0 0 3 2
## Valiant 18.1 6 225 105 2.76 3.460 20.22 1 0 3 1


# 상관행렬 생성
car_cor <- cor(mtcars)
# 소수점 셋째 자리에서 반올림해 출력
round(car_cor, 2) 
## mpg cyl disp hp drat wt qsec vs am gear carb
## mpg 1.00 -0.85 -0.85 -0.78 0.68 -0.87 0.42 0.66 0.60 0.48 -0.55
## cyl -0.85 1.00 0.90 0.83 -0.70 0.78 -0.59 -0.81 -0.52 -0.49 0.53
## disp -0.85 0.90 1.00 0.79 -0.71 0.89 -0.43 -0.71 -0.59 -0.56 0.39
## hp -0.78 0.83 0.79 1.00 -0.45 0.66 -0.71 -0.72 -0.24 -0.13 0.75
## drat 0.68 -0.70 -0.71 -0.45 1.00 -0.71 0.09 0.44 0.71 0.70 -0.09

install.packages("corrplot")
library(corrplot)
corrplot(car_cor)

# 출력된 히트맵을 보면 상관계수가 클수록 원의 크기가 크고 색깔이 진합니다. 상관계수가 양수면 파란색, 음수면 빨간색 계열로 표현되어 있습니다. 원의 크기와 색깔을 보면 상관관계의 정도와 방향을 쉽게 파악할 수 있습니다.

corrplot(car_cor, method = "number")




# colorRampPalette()로 색상 코드 목록을 생성한 후 col 파라미터에 지정하겠습니다.
col <- colorRampPalette(c("#BB4444", "#EE9988", "#FFFFFF", "#77AADD","#4477AA"))
corrplot(car_cor,
         method = "color", # 색깔로 표현
         col = col(200), # 색상 200개 선정
         type = "lower", # 왼쪽 아래 행렬만 표시
         order = "hclust", # 유사한 상관계수끼리 군집화
         addCoef.col = "black", # 상관계수 색깔
         tl.col = "black", # 변수명 색깔
         tl.srt = 45, # 변수명 45도 기울임
         diag = F) # 대각 행렬 제외
