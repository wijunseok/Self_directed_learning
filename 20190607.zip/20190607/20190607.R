# 14장 
# R MarkDown 으로 데이터 분석 보고서 만들기

# 14장 - 1
# 신뢰할 수 있는 데이터 분석 보고서 만들기

# R 마크 다운을 활용하면 데이터 분석의 전 과정을 담은 보고서를 쉽게 만들 수 있다.
# HTML , 워드 , PDF 등 다양한 포맷으로 저장할 수 있기 때문에 별도의 문서 작성 소프트웨어를 사용하지 않아도 된다.
# 데이터 분석 보고서를 신뢰 할 수 있으려면 동일한 분석 과정을 거쳤을 때 동일한 분석 결과가 반복되어 나오도록 재현성을 갖춰야 합니다.

# 14장 - 2
# R 마크다운 문서 만들기
# File - New File - R MarkDown
# HTML , PDF , WORD 중에서 저장할 문서 선택하고 , 저장하면 작성된 예제 문서가 만들어진다.
# PDF 파일로 저장할 때는 프로그램과 패키지를 설치해야 한다. 
# 1. TeX 소프트웨어 설치 : MiKTeX 설치 - R 스튜디오 재실한 후 R 마크다운 문서 상단의 Output 부분을 수정
# 2.
# ---
# oupput :
# pdf_document :
# latex_engine : xelatex
# mainfont : MalgunGothic
# ---
# 3. Knit to PDF - Package Installation - Always Show this dialog before installing packages의 체크 해제 , Install

# P 312 참조하기

# * 기울임체 , ** 강조체 , ~~ 취조선 , []() 대괄호안에 문자 , 가로안에 링크 - 하이퍼 링크


# 15 장
# R 내장 함수 , 변수 타입과 데이터 구조

# 15장 - 1
# R 내장 함수로 데이터 추출
# dplyr 패키지를 이용하지 않고 R 에 기본적으로 내장되어 있는 함수들만 사용해도 데이터룰 추출할 수 있다.
exam = read.csv("csv_exam.csv")
exam[] # 조건 없이 전체 데이터 출력
exam[1,3] # 인덱스를 이용해 데이터를 추출하는 작업을 '인덱싱' 이라고 한다.
exam[2,] # 왼쪽 - 인데스 , 오른쪽 - 행 

exam[exam$class == 1, ] # class 가 1인 행 추출
exam[exam$math >= 80 , ] # 수학 점수가 80 점 이상인 행 추출
exam[exam$class==2 & exam$science >= 50 ,]
exam[ , "class"]
exam[ , "math"]
exam[ , c( "class","math" , "english" , "science")]
exam[exam$math >= 50 , c("english" , "science")]

install.packages("dplyr")
library(dplyr)

# dplyr 과 내장 함수의 차이
exam$tot = (exam$math + exam$english + exam$science)/3
# aggregate() 는 범주별 요약 통계량을 구하는 R 내장 함수수
aggregate(data = exam[exam$math >= 50 & exam$english >= 80 ,], tot~class , mean)
# dplyr 코드
exam %>% filter(math >= 50 & english >= 80) %>% mutate(tot = (math + english + science)/3) %>% group_by(class) %>% summarise(mean = mean(tot))

# 15장 - 2
# 변수 타입
# 변수에는 여러가지 타입이 있습니다.
# 변수의 종류 : 연속 변수 , 범주 변수수
# 연속 변수 - Numeric 타입
# 연속 변수는 키, 몸무게 , 소득처럼 연속적이고 크기를 의미하는 값으로 구성된 변수
# 숫자가 크기를 지니기 때문에 더하기, 빼기 , 평균 구하기 등 산술을 할 수 있다.
# 연속 변수는 '양적 변수' 라고도 합니다. R 에서 연속변수는 Numeric(뉴머릭) 으로 표현한다.

# 범주 변수
# 범주 변수는 숫자가 대상을 지칭하는 이름과 같은 역할을 하기 때문에 '명목 변수' 라고도 합니다.
# R에서 범주 변수는 'factor' 로 표현된다.

var1 = c(1,2,3,1,2)
var2 = factor(c(1,2,3,1,2))
table(var1)
table(var2)

class(var1)
class(var2)

levels(var1)
levels(var2)

# 함수마다 적용 가능한 변수 타입이 다르다
# 예를 들어 , 평균을 구하는 함수 mean()에는 numeric 변수만 적용할 수 있다. factor 변수에 적용하면 에러가 발생한다.

# 변수 타입을 변환하는 방법
var2 = as.numeric(var2)

# 15장 - 3
# 데이터 구조

# 벡터 1차원 한 가지 변수 타입으로 구성
# 데이터 프레임 2차원 다양한 변수 타입으로 구성 data.frame(var1 = c(1,2,3) , var2 = c("a","b","c"))
# 매트릭스 2차원 한 가지 변수 타입으로 구성 matrix(c(1:12) , ncol=2)
# 어레이 다차원 2차원 이상의 매트릭스 array(1:20 , dim(2,5,2))
# 리스트 다차원 서로 다른 데이터 구조 포함 list(f1 = a, f2 = x1, f3 = x2 , f4 = x3)

# 함수의 결과물이 리스트 형태로 반환되는 경우가 많기 때문에 리스트는 R에서 특히 중요한 데이터 구조입니다.
# 예를 들어 , boxplot() 출력 결과는 리스트 형태이기 때문에 리스트 구조를 다루는 문법을 이용하면 원하는 값을 추출 할 수 있습니다.


# 16장
# 데이터 분석 기술을 효율적으로 익히는 방법
# 16장 - 1 
# 집중할 방향 정하기
# 데이터 분석 , 데이터 엔지니어링 , 데이터 시각화화 , 웹 애널리틱스스



